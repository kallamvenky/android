package com.thenottodo.news;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class Apple extends Fragment {
    private static final String url_data = "https://newsapi.org/v2/everything?q=apple&from=2018-01-09&to=2018-01-09&sortBy=popularity&apiKey=a2a6be4baadc4500a92c88d2ad83b390";

    //a list to store all the products
    List<Product> productList;

    Context mCtx;

    //the recyclerview
    RecyclerView recyclerView;
    String author,title,url,img_url;


    private Fragment selectedFragment = null;
    View apple;

    public static Apple newInstance() {
        Apple fragment = new Apple();
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        apple = inflater.inflate(R.layout.fragment_apple, container, false);
        recyclerView = apple.findViewById(R.id.applerecyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(mCtx,LinearLayoutManager.VERTICAL,false));
        recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));


        productList = new ArrayList<>();
        loadRecyclerViewData();

        return apple;

    }


    public void loaddata(){

        productList.add(
                new Product(
                        author,
                        title,
                        url,
                        img_url
                ));
        //creating recyclerview adapter
        AppleProductAdapter adapter = new AppleProductAdapter( getActivity(), productList);


        //setting adapter to recyclerview
        recyclerView.setAdapter(adapter);
    }

    private void loadRecyclerViewData(){


        final ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Loading Data.....");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url_data,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        progressDialog.dismiss();

                        try {

                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("articles");


                            for(int i = 0; i< jsonArray.length();i++){
                                JSONObject o = jsonArray.getJSONObject(i);

                                author = o.getString("author");
                                title = o.getString("title");
                                url = o.getString("url");
                                img_url = o.getString("urlToImage");



                                loaddata();

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        //Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);
    }


}
