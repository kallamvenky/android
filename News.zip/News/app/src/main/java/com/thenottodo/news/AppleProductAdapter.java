package com.thenottodo.news;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

/**
 * Created by VSQUARE on 09-01-2018.
 */

public class AppleProductAdapter extends RecyclerView.Adapter<AppleProductAdapter.ProductViewHolder> {



    //this context we will use to inflate the layout
    private Context mCtx ;

    //we are storing all the products in a list
    private List<Product> productList;

    //getting the context and product list with constructor
    public AppleProductAdapter(Context mCtx, List<Product> productList) {
        this.mCtx = (Context) mCtx;
        this.productList = (List<Product>) productList;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.apple_layout_products, null);
        RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        view.setLayoutParams(lp);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProductViewHolder holder, int position) {
        //getting the product of the specified position
        final Product product = productList.get(position);

        //binding the data with the viewholder views
        holder.textViewAuthor.setText(product.getAuthor());
        holder.textViewTitle.setText(product.getTitle());
        //holder.textViewurl.setText(product.getUrl());
        //Glide.with(mCtx).load(product.getImage()).into(holder.imageView);


        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(mCtx,pageView.class);
                intent.putExtra("url",product.getUrl());
                mCtx.startActivity(intent);

                Log.i("info",product.getUrl());

            }
        });

        //holder.imageView.setImageDrawable(mCtx.getResources().getDrawable(product.getImage()));

    }


    @Override
    public int getItemCount() {
        return productList.size();
    }


    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewAuthor, textViewTitle,textViewurl;
        ImageView imageView;
        LinearLayout relativeLayout;

        public ProductViewHolder(View itemView) {
            super(itemView);

            textViewAuthor = itemView.findViewById(R.id.appleAuthor);
            textViewTitle = itemView.findViewById(R.id.appleTitle);
            //textViewurl = itemView.findViewById(R.id.textViewurl);

            relativeLayout = itemView.findViewById(R.id.applelinearlayout);
            //imageView = itemView.findViewById(R.id.techCrunchimageView);
        }
    }
}
