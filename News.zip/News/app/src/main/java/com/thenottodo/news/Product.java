package com.thenottodo.news;

/**
 * Created by VSQUARE on 09-01-2018.
 */
public class Product {

    private String author;
    private String title;
    private String image;
    private String url;


    public Product( String author, String title, String url, String image) {
        this.author = author;
        this.title = title;
        this.image = image;
        this.url = url;
    }


    public String getAuthor() {
        return author;
    }

    public String getUrl() {
        return url;
    }


    public String getImage() {
        return image;
    }
    public String getTitle() {
        return title;
    }


}